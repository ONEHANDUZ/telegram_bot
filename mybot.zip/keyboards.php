<?php
$k_main = json_encode([
    'resize_keyboard' => true,
    'keyboard' => [
        [['text'=>'/farzandim'],['text'=>'/monitoring']]
    ]
    ]);
$k_remove = json_encode([
    'remove_keyboard' => true,
    ]);
?>

<?php
$t_start = "Salom";
$t_reg_1 = "F.I. kiriting.
Namuna: Asadov Asad";
$t_reg_2 = "Telefon raqam kiriring.
Namuna: +998901234567";
$t_reg_3 = "Maktab tomonidan berilgan 5 xonali ID raqamni kiriting.";
$t_reg_off = "Hurmatli ota-ona siz bizning botimizdan muvaffaqiyarli ro'yxatdan o'tdingiz.

1)Farzandingiz ma'lumotlarini ko'rmoqchi bo'lsangiz /farzandim buyrug'ini yuboring.

2)Monitoringda olgan natijasini ko'rmoqchi bo'lsangiz /monitoring buyrug'ini yuboring.";
$t_monitoring = "Monitoring";
$t_farzandim = "Farzandim";
?>
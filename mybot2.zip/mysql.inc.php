<?php
// DATABASE INFO
$db_server_name = "localhost";
$db_user_name = "infom_mydb1";
$db_password ="2x!28hVu";
$db_name = "infomuminovlog_mydb";
$db_table_name = "boo";
//connect
$mysqli = new mysqli($db_server_name, $db_user_name, $db_password, $db_name);
?>
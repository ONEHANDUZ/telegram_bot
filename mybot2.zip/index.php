<?php
// API_TOKEN
define('API_KEY','1475172949:AAHVUq9tiBQh3ziM0Nl5J6zaf7R-YdQMeRk');

// INCLUDES
include 'functions.php';//metodlar
include 'values.php';//o'zgaruvchilar
include 'keyboards.php';//keyboardlar
include 'texts.php';//textlari
include 'mysql.inc.php';//mysql

//sql
$select = "SELECT * FROM $db_table_name";
$result = mysqli_query($mysqli, $select);
$resultCheck = mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);
$row2 = get("data/users.dat");
$tid = mb_stripos($row2, $cid);
$sqlname = get("data/$cid.phone");
$sqlmid = get("data/$cid.phone");
$sqlphone = get("data/$cid.phone");
//BASIC CMD
if($txt=="/start"){
    if ($resultCheck > 0) {// :)
        if ($tid !== false) {
            sendmessage($cid,$t_start,$k_main);
        }else{
            put("data/$cid.dat", "reg1");
            sendmessage($cid,$t_reg_1,$k_remove);
        }
    }
}
if($txt=="/startt"){
    sendmessage($cid,$t_start,$k_main);
}

if($txt=="/farzandim"){
    if ($resultCheck > 0) {// :)
        if ($tid !== false) {
            sendmessage($cid,$t_farzandim,$k_main);
        }else {
            put("data/$cid.dat", "reg1");
            sendmessage($cid,$t_reg_1,$k_remove);
        }
    }
}

if($txt=="/monitoring"){
    if ($resultCheck > 0) {// :)
        if ($tid !== false) {
            sendmessage($cid,$t_monitoring,$k_main);
        }else {
            put("data/$cid.dat", "reg1");
            sendmessage($cid,$t_reg_1,$k_remove);
        }
    }
}


if ($step == "reg1"){
        put("data/$cid.name", "$txt");
        put("data/$cid.dat", "reg2");
        sendmessage($cid,$t_reg_2,$k_remove);
    }
    if ($step == "reg2") {
            put("data/$cid.phone", "$txt");
            put("data/$cid.dat", "reg3");
            sendmessage($cid,$t_reg_3,$k_remove);
    }
    if ($step == "reg3") {
        put("data/$cid.mid", "$txt");
        put("data/$cid.dat", "//");
        $sql = "INSERT INTO boo (tid, name, phone, mid)
        VALUES ('$cid', '$sqlname', '$sqlphone', '$sqlmid')";
        $foo = $mysqli->query($sql);
        put("data/users.dat", "$cid\n");
        sendmessage($cid,$t_reg_off,$k_main);
    }
?>
Manzil : @onehanduz
qillinnaidgan ishlarim:
//.1. mysql ulashim,
.2. query bilan ishlash
//.3. isset qilishim /start uchun agar bazada bo'lsa odatiy holatda ishlayveradi.
//.4. kelinga textni validatsiya qiliahsim kerak 1. familas is so'raydi. 2.  telefon raqam so'raydi 3. maktab tomonidan berilgan id;;
//.5. regdan o'tkanidan keyin text massage yuborish
/.6. /farzand buyrug'i berilsa farzand haqida malumot yuborish
/.7. /monitoring da monitoring baholarini ko'rishi kerak 

1. real bilan ishlab ko'rsam bo'ldi endim.
2. lekin monitoring + farzandim clientda so'rab ko'rishim kerak.
.3. keyin 3ta validatsiyani ham mukkamal qilishm kerak. Bu uncha shart emas muhimi  maktab ID ni tekshirib ko'rishim kerak buning uchun maktab "id" dan foydalashim kerak
<?php
// DATABASE INFO
$db_server_name = "localhost";
$db_user_name = "root";
$db_password ="mysql";
$db_name = "forbot";
$db_table_name = "forbot";
//connect
$mysqli = mysqli_connect($db_server_name, $db_user_name, $db_password, $db_name);
?>